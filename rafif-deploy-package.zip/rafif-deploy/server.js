import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import OpenAI from 'openai';
import webpush from 'web-push';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;
const DATABASE_URL = process.env.DATABASE_URL;
const pool = DATABASE_URL ? new pg.Pool({ connectionString: DATABASE_URL, ssl: DATABASE_URL.includes('localhost') ? false : { rejectUnauthorized: false } }) : null;
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const vapidReady = !!(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY && process.env.VAPID_SUBJECT);
if (vapidReady) webpush.setVapidDetails(process.env.VAPID_SUBJECT, process.env.VAPID_PUBLIC_KEY, process.env.VAPID_PRIVATE_KEY);
if (!JWT_SECRET) console.warn('WARNING: JWT_SECRET is missing. Set it in your hosting environment.');
if (!pool) console.warn('WARNING: DATABASE_URL is missing. Account and shared features will not work.');

app.use(express.json({ limit: '12mb' }));
app.use(express.static(path.join(__dirname, 'public')));
const GV = ['الجهراء','العاصمة','حولي','الفروانية','مبارك الكبير','الأحمدي'];
const roles = ['farmer','beekeeper'];
const safeUser = u => ({ id: u.id, name: u.name, username: u.username, role: u.role, gov: u.gov == null ? null : Number(u.gov) });
const fail = (res, status, error) => res.status(status).json({ error });
async function dbReady() {
  if (!pool) throw Object.assign(new Error('database_not_configured'), { code: 'database_not_configured' });
  await pool.query(`CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, username TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('farmer','beekeeper')), gov INTEGER,
    password_hash TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS notifications (
    id BIGSERIAL PRIMARY KEY, sender_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    recipient_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type TEXT NOT NULL, farm TEXT NOT NULL, gov INTEGER, event_when TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'new' CHECK(status IN ('new','seen','handled')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS alerts (
    id BIGSERIAL PRIMARY KEY, sender_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    farm TEXT NOT NULL, gov INTEGER, event_when TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
  await pool.query(`CREATE TABLE IF NOT EXISTS push_subscriptions (
    id BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    endpoint TEXT UNIQUE NOT NULL, subscription JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
}
const db = async (sql, values=[]) => { await dbReady(); return pool.query(sql, values); };
function auth(req,res,next) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) return fail(res,401,'auth_required');
  try { if (!JWT_SECRET) throw new Error(); req.user = jwt.verify(h.slice(7), JWT_SECRET); next(); }
  catch { return fail(res,401,'auth_required'); }
}
const role = wanted => (req,res,next) => req.user?.role === wanted ? next() : fail(res,403,'forbidden');
const toDate = r => new Date(r.created_at).getTime();
function notifRow(r) { return { id:String(r.id), status:r.status, type:r.type, fromName:r.from_name, ts:toDate(r), farm:r.farm, g:r.gov == null ? null : Number(r.gov), when:r.event_when, note:r.note || '' }; }
function alertRow(r, userId) { return { id:String(r.id), farm:r.farm, g:r.gov == null ? null : Number(r.gov), when:r.event_when, note:r.note || '', ts:toDate(r), by:String(r.sender_id), mine:String(r.sender_id)===String(userId) }; }
async function sendPush(userId, payload) {
  if (!vapidReady) return false;
  const { rows } = await db('SELECT id, subscription FROM push_subscriptions WHERE user_id=$1', [userId]);
  let sent=false;
  for (const r of rows) { try { await webpush.sendNotification(r.subscription, JSON.stringify(payload)); sent=true; } catch(e) { if (e.statusCode===404 || e.statusCode===410) await db('DELETE FROM push_subscriptions WHERE id=$1',[r.id]); } }
  return sent;
}
app.get('/api/health', async (req,res) => { try { if(pool) await dbReady(); res.json({ok:true,database:!!pool,ai:!!openai,push:vapidReady}); } catch { res.status(503).json({ok:false,database:false,ai:!!openai,push:vapidReady}); } });
app.post('/api/register', async (req,res) => {
  try {
    const { name, username, password, role: userRole, gov } = req.body || {};
    const n=String(name||'').trim(), u=String(username||'').trim().toLowerCase(), p=String(password||'');
    if(n.length<2) return fail(res,400,'bad_name');
    if(!/^[a-zA-Z0-9_.-]{3,24}$/.test(u)) return fail(res,400,'bad_username');
    if(p.length<6 || p.length>200) return fail(res,400,'bad_password');
    if(!roles.includes(userRole)) return fail(res,400,'bad_role');
    const g=gov===null||gov===''||gov===undefined?null:Number(gov); if(g!==null&&(!Number.isInteger(g)||g<0||g>=GV.length))return fail(res,400,'bad_request');
    const hash=await bcrypt.hash(p,12);
    const {rows}=await db('INSERT INTO users(name,username,role,gov,password_hash) VALUES($1,$2,$3,$4,$5) RETURNING *',[n,u,userRole,g,hash]);
    const user=safeUser(rows[0]); const token=jwt.sign(user,JWT_SECRET,{expiresIn:'30d'}); return res.status(201).json({user,token});
  } catch(e) { if(e.code==='23505')return fail(res,409,'username_taken'); console.error(e);return fail(res,500,'server_error'); }
});
app.post('/api/login', async (req,res) => { try { const u=String(req.body?.username||'').trim().toLowerCase(),p=String(req.body?.password||''); const {rows}=await db('SELECT * FROM users WHERE username=$1',[u]); if(!rows[0]||!(await bcrypt.compare(p,rows[0].password_hash)))return fail(res,401,'bad_credentials');const user=safeUser(rows[0]);return res.json({user,token:jwt.sign(user,JWT_SECRET,{expiresIn:'30d'})}); } catch(e){console.error(e);return fail(res,500,'server_error')} });
app.get('/api/me',auth,async(req,res)=>{try{const {rows}=await db('SELECT * FROM users WHERE id=$1',[req.user.id]);if(!rows[0])return fail(res,401,'auth_required');res.json({user:safeUser(rows[0])})}catch(e){console.error(e);fail(res,500,'server_error')}});
app.post('/api/logout',auth,(req,res)=>res.json({ok:true}));
app.get('/api/beekeepers',auth,async(req,res)=>{try{const {rows}=await db("SELECT id,name,gov FROM users WHERE role='beekeeper' ORDER BY name");res.json({beekeepers:rows.map(x=>({id:String(x.id),name:x.name,gov:x.gov==null?null:Number(x.gov)}))})}catch(e){console.error(e);fail(res,500,'server_error')}});
app.get('/api/notifications',auth,async(req,res)=>{try{
 if(req.query.box==='out'&&req.user.role==='farmer') {const {rows}=await db(`SELECT n.*,u.name recipient_name FROM notifications n JOIN users u ON u.id=n.recipient_id WHERE n.sender_id=$1 ORDER BY n.created_at DESC LIMIT 200`,[req.user.id]);const ids=rows.map(x=>x.id);const counts=ids.length?await db(`SELECT sender_id, type, farm, event_when, COUNT(*)::int recipients, COUNT(*) FILTER(WHERE status IN ('seen','handled'))::int seen, COUNT(*) FILTER(WHERE status='handled')::int handled FROM notifications WHERE sender_id=$1 GROUP BY sender_id,type,farm,event_when`,[req.user.id]):{rows:[]};res.json({sent:counts.rows.map(x=>({type:x.type,farm:x.farm,when:x.event_when,ts:Date.now(),recipients:x.recipients,seen:x.seen,handled:x.handled}))});return;}
 if(req.user.role!=='beekeeper')return fail(res,403,'forbidden');const {rows}=await db(`SELECT n.*,u.name from_name FROM notifications n JOIN users u ON u.id=n.sender_id WHERE n.recipient_id=$1 ORDER BY n.created_at DESC LIMIT 200`,[req.user.id]);res.json({notifications:rows.map(notifRow)});
 }catch(e){console.error(e);fail(res,500,'server_error')}});
app.post('/api/notifications/:id/status',auth,role('beekeeper'),async(req,res)=>{try{const status=req.body?.status;if(!['new','seen','handled'].includes(status))return fail(res,400,'bad_request');const {rows}=await db('UPDATE notifications SET status=$1 WHERE id=$2 AND recipient_id=$3 RETURNING *',[status,req.params.id,req.user.id]);if(!rows[0])return fail(res,404,'not_found');const q=await db('SELECT name FROM users WHERE id=$1',[rows[0].sender_id]);res.json({notification:notifRow({...rows[0],from_name:q.rows[0]?.name||''})})}catch(e){console.error(e);fail(res,500,'server_error')}});
app.post('/api/notifications',auth,role('farmer'),async(req,res)=>{try{const {type,scope,g,to,farm,when,note}=req.body||{};if(!['spray','request'].includes(type)||!String(farm||'').trim()||!String(when||'').trim())return fail(res,400,'bad_request');let recipients;
 if(scope==='user'){const q=await db("SELECT id FROM users WHERE role='beekeeper' AND id=$1",[to]);recipients=q.rows;}
 else if(scope==='gov'){const gg=Number(g);if(!Number.isInteger(gg)||gg<0||gg>=GV.length)return fail(res,400,'bad_request');const q=await db("SELECT id FROM users WHERE role='beekeeper' AND gov=$1",[gg]);recipients=q.rows;}
 else if(scope==='all'){const q=await db("SELECT id FROM users WHERE role='beekeeper'");recipients=q.rows;} else return fail(res,400,'bad_request');
 if(!recipients.length)return fail(res,400,'no_recipients');for(const r of recipients){const ins=await db('INSERT INTO notifications(sender_id,recipient_id,type,farm,gov,event_when,note) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id',[req.user.id,r.id,type,String(farm).trim().slice(0,120),g==null?null:Number(g),String(when).slice(0,100),String(note||'').slice(0,1000)]);await sendPush(r.id,{title:'رفيف – تنبيه للنحالين',body:`${type==='spray'?'تنبيه رش مبيدات':'طلب تلقيح'}: ${farm}، ${when}`,url:'/'}).catch(()=>{});}res.json({sent:recipients.length,pushed:0});
 }catch(e){console.error(e);fail(res,500,'server_error')}});
app.post('/api/push/subscribe',auth,async(req,res)=>{try{const {endpoint}=req.body||{};if(!endpoint)return fail(res,400,'bad_request');const {rows}=await db('INSERT INTO push_subscriptions(user_id,endpoint,subscription) VALUES($1,$2,$3) ON CONFLICT(endpoint) DO UPDATE SET user_id=EXCLUDED.user_id,subscription=EXCLUDED.subscription RETURNING id',[req.user.id,endpoint,JSON.stringify(req.body)]);res.json({ok:true,id:String(rows[0].id)})}catch(e){console.error(e);fail(res,500,'server_error')}});
app.delete('/api/push/subscribe',auth,async(req,res)=>{try{await db('DELETE FROM push_subscriptions WHERE user_id=$1 AND endpoint=$2',[req.user.id,req.body?.endpoint||'']);res.json({ok:true})}catch(e){console.error(e);fail(res,500,'server_error')}});
app.get('/api/vapid-public',(req,res)=>res.json({key:process.env.VAPID_PUBLIC_KEY||''}));
app.get('/api/alerts',auth,async(req,res)=>{try{const {rows}=await db('SELECT * FROM alerts WHERE created_at>NOW()-INTERVAL \'24 hours\' ORDER BY created_at DESC LIMIT 100');res.json({alerts:rows.map(r=>alertRow(r,req.user.id))})}catch(e){console.error(e);fail(res,500,'server_error')}});
app.post('/api/alerts',auth,role('farmer'),async(req,res)=>{try{const {farm,g,when,note}=req.body||{};const f=String(farm||'').trim(),w=String(when||'').trim(),gg=Number(g);if(!f||!w||!Number.isInteger(gg)||gg<0||gg>=GV.length)return fail(res,400,'bad_request');const {rows}=await db('INSERT INTO alerts(sender_id,farm,gov,event_when,note) VALUES($1,$2,$3,$4,$5) RETURNING *',[req.user.id,f.slice(0,120),gg,w.slice(0,100),String(note||'').slice(0,1000)]);const keep=await db("SELECT id FROM users WHERE role='beekeeper' AND (gov=$1 OR gov IS NULL)",[gg]);for(const u of keep.rows)await sendPush(u.id,{title:'رفيف – تنبيه مبيدات',body:`مزرعة ${f} (${GV[gg]}) سترش مبيدات ${w}. أغلق خلاياك الآن.`,url:'/'}).catch(()=>{});res.json({alert:alertRow(rows[0],req.user.id),sent:keep.rows.length})}catch(e){console.error(e);fail(res,500,'server_error')}});
app.delete('/api/alerts/:id',auth,async(req,res)=>{try{const {rowCount}=await db('DELETE FROM alerts WHERE id=$1 AND sender_id=$2',[req.params.id,req.user.id]);if(!rowCount)return fail(res,404,'not_found');res.json({ok:true})}catch(e){console.error(e);fail(res,500,'server_error')}});
app.post('/api/analyze',auth,async(req,res)=>{try{
 if(!openai)return fail(res,503,'analysis_not_configured');const {stage,image,v}=req.body||{};if(![1,2].includes(Number(stage))||typeof image!=='string')return fail(res,400,'bad_request');if(image.length>10_000_000)return fail(res,413,'too_large');
 const prompt = Number(stage)===1 ? 'أنت مدقّق صور لتطبيق نحالة. مهمتك فقط تحديد هل الصورة مناسبة لفحص صحة خلية نحل، دون تحليل الصحة. صنّف الصورة في category واحد: brood_frame، comb، bees_on_comb، hive_entrance، hive_other، single_bee_or_flower، not_hive، unclear. لا تخمّن. أعد JSON فقط: {"category":"...","recognition_confidence":0-100,"quality":{"level":"good|fair|poor","issues":["blur|dark|too_far|glare|too_close|low_detail"]},"visible_parts":["أجزاء ظاهرة بالعربية"],"reason":"جملة عربية قصيرة"}.' : `أنت خبير نحالة تحلّل صورة خلية نحل تحققنا مسبقًا أنها ${JSON.stringify(v||{})}. صف فقط ما تراه ولا تخترع، ولا تؤكد تشخيص مرض، ولا تقل إن الخلية سليمة. ابحث عن علامات مرئية قد تدل على مشكلة، مع بدائل وفحوص ميدانية. لا تقيّم قوة الطائفة من صورة قريبة صغيرة. أعد JSON فقط بالعربية: {"summary":"جملتان","findings":[{"name":"","observed":"","location":null,"clarity":"clear|moderate|faint","may_indicate":"","alternatives":[""],"field_check":"","confidence":0-100}],"chalkbrood":{"signs_visible":false,"observed":null,"confidence":null,"other_possibilities":[""],"needs_check":""},"strength":{"assessable":false,"reason":"","brood_pattern":null,"adult_bees":null,"not_visible":[""]}}`;
 const dataUrl=`data:image/jpeg;base64,${image}`;const response=await openai.chat.completions.create({model:process.env.OPENAI_MODEL||'gpt-4o-mini',temperature:0.2,response_format:{type:'json_object'},messages:[{role:'system',content:prompt},{role:'user',content:[{type:'text',text:'حلّل هذه الصورة وفق التعليمات وأعد JSON فقط.'},{type:'image_url',image_url:{url:dataUrl,detail:'high'}}]}]});const text=response.choices?.[0]?.message?.content;if(!text)return fail(res,502,'upstream_failed');res.json({text});
 }catch(e){console.error('analysis error',e?.message||e);if(e.status===429)return fail(res,429,'rate_limited');fail(res,502,'upstream_failed')}});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'server_error'})});
app.listen(PORT,()=>console.log(`Rafif server listening on ${PORT}`));
