# Rafif Bees API (Render + Gemini)

This service provides `POST /api/analyze` for the Rafif Bees frontend.

## Render setup
- Runtime: Node
- Root Directory: `rafif-api` (if these files are in a folder named `rafif-api` in the repository)
- Build Command: `npm install`
- Start Command: `npm start`
- Environment variable: `GEMINI_API_KEY` = your key from Google AI Studio (keep secret)
- Optional: `GEMINI_MODEL` = `gemini-2.5-flash`

After deployment, set `API_URL` in the frontend to the full Render service URL, e.g. `https://your-service.onrender.com` (no trailing slash).

This is an image-analysis endpoint only. It does not implement account storage or notifications.
