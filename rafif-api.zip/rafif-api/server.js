import express from 'express';
import cors from 'cors';
import { GoogleGenAI } from '@google/genai';

const app = express();
app.use(cors({ origin: [/^https:\/\/eng-maryam-2003\.github\.io$/], methods: ['GET','POST','OPTIONS'], allowedHeaders: ['Content-Type','Authorization'] }));
app.use(express.json({ limit: '12mb' }));

const PORT = process.env.PORT || 10000;
const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

app.get('/', (_req, res) => res.json({ service: 'rafif-bees-api', status: 'ok' }));
app.get('/health', (_req, res) => res.json({ status: 'ok', configured: Boolean(API_KEY) }));

const cats = {
  brood_frame: 'إطار شمعي فيه حضنة', comb: 'أقراص شمعية داخل خلية',
  bees_on_comb: 'نحل بالغ على الأقراص', hive_entrance: 'مدخل خلية نحل', hive_other: 'جزء من خلية نحل'
};
const stage1 = `أنت مدقّق صور لتطبيق نحالة. حدّد فقط هل الصورة مناسبة لفحص صحة خلية نحل، دون تحليل الصحة. اختر category واحدة من: brood_frame (إطار حضنة)، comb (أقراص شمعية)، bees_on_comb (نحل على الأقراص)، hive_entrance (مدخل خلية)، hive_other (جزء واضح من الخلية)، single_bee_or_flower (نحلة منفردة أو زهرة)، not_hive (أي شيء آخر)، unclear (غير واضح). لا تخمّن. أعد JSON فقط بهذا الشكل: {"category":"...","recognition_confidence":0,"quality":{"level":"good|fair|poor","issues":[]},"visible_parts":["أجزاء ظاهرة بالعربية"],"reason":"جملة عربية قصيرة"}. issues يمكن أن تحتوي: blur,dark,too_far,glare,too_close,low_detail.`;
function stage2(v={}) {
  return `أنت خبير نحالة تحلّل صورة خلية نحل صُنّفت كـ ${cats[v.category] || 'خلية نحل'} (الأجزاء الظاهرة: ${(v.visible_parts || []).join('، ')}). صف فقط ما تراه فعلًا، ولا تخترع ولا تؤكد تشخيص مرض ولا تقل إن الخلية سليمة. افحص بصريًا علامات واضحة مثل حضنة متناثرة أو غير منتظمة، يرقات ميتة أو متغيرة اللون، أغطية مثقوبة أو غائرة، بقايا حضنة ميتة أو نحل ميت كثير. لا تعتبر بقعة بيضاء وحدها دليلًا على مرض. لا تقيّم قوة الطائفة من صورة قريبة لجزء صغير. أعد JSON فقط بالعربية بهذا الشكل: {"summary":"جملتان","findings":[{"name":"","observed":"ما رأيته فعلًا","location":null,"clarity":"clear|moderate|faint","may_indicate":"","alternatives":[],"field_check":"ما يفحصه النحّال ميدانيًا","confidence":0}],"chalkbrood":{"signs_visible":false,"observed":null,"confidence":null,"other_possibilities":[],"needs_check":""},"strength":{"assessable":false,"reason":"","brood_pattern":null,"adult_bees":null,"not_visible":[]}}. هذه ملاحظة بصرية أولية وليست تشخيصًا بيطريًا.`;
}
app.post('/api/analyze', async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: 'analysis_not_configured' });
    const { stage, image, v } = req.body || {};
    if (typeof image !== 'string' || image.length < 100) return res.status(400).json({ error: 'bad_image_size' });
    const clean = image.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, '');
    const buffer = Buffer.from(clean, 'base64');
    if (buffer.length < 100 || buffer.length > 8 * 1024 * 1024) return res.status(400).json({ error: 'bad_image_size' });
    const mimeType = String(req.body.mimeType || 'image/jpeg').toLowerCase();
    if (!['image/jpeg','image/png','image/webp'].includes(mimeType)) return res.status(415).json({ error: 'unsupported_image' });
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const prompt = Number(stage) === 1 ? stage1 : stage2(v || {});
    const result = await ai.models.generateContent({
      model: MODEL,
      contents: [{ role: 'user', parts: [{ text: prompt }, { inlineData: { mimeType, data: buffer.toString('base64') } }] }],
      config: { responseMimeType: 'application/json', temperature: 0.2 }
    });
    const text = result.text;
    if (!text) return res.status(502).json({ error: 'upstream_failed' });
    return res.json({ text });
  } catch (err) {
    console.error('analysis error:', err?.message || err);
    return res.status(502).json({ error: 'upstream_failed' });
  }
});
app.listen(PORT, '0.0.0.0', () => console.log(`Rafif API listening on ${PORT}`));
